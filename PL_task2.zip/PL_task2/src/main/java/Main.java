import org.w3c.dom.ls.LSOutput;

public class Main {

    public static void main(String[] args) {
        Author author = new Author("Пётр Камнев", "peterthestone@gmail.com", 'м');
        Book book = new Book("Каменный цветок", author, 7.99, 10);
        Author author1 = new Author("Нге Пушта", "pushta@gmail.com", 'ж');
        Book book1 = new Book("Королева Африки", author1, 3.99, 4);

        System.out.println(book);
        System.out.println(book1);
    }




}
