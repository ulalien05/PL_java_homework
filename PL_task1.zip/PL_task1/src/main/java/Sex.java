public enum Sex {
    MALE,
    FEMALE
}
