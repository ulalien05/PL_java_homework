public class Animal {

    private String name;

    private int age;

    private Sex sex;

    private int runLimit;

    private int swimLimit;

    public void setRunLimit(int runLimit) {
        this.runLimit = runLimit;
    }

    public void setSwimLimit(int swimLimit) {
        this.swimLimit = swimLimit;
    }

    public int getSwimLimit() {
        return swimLimit;
    }

    public int getRunLimit() {
        return runLimit;
    }

    public Animal(){}

    public Animal(String name, int age, Sex sex) {
        this.name = name;
        this.age = age;
        this.sex = sex;
    }

    public void run(int distance) {

        if (distance <= this.runLimit) {
            if (this.sex == Sex.MALE)
                System.out.printf("%s пробежал %d метров.\n", name, distance);
            else
                System.out.printf("%s пробежала %d метров.\n", name, distance);
        } else {
            System.out.printf("%s не может пробежать больше %d метров.\n", this.getName(), this.runLimit);
        }
    }

    public void swim(int distance) {

        if (distance <= this.swimLimit) {
            if (this.sex == Sex.MALE)
                System.out.printf("%s проплыл %d метров.\n", name, distance);
            else
                System.out.printf("%s проплыла %d метров.\n", name, distance);
        } else {
            System.out.printf("%s не может проплыть больше %d метров.\n", this.getName(), this.swimLimit);
        }
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public Sex getSex() {
        return sex;
    }

    public void setSex(Sex sex) {
        this.sex = sex;
    }
}
