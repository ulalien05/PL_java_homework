public class Duck extends Animal{

    private static int count = 0;

    public Duck() {
        count++;
    }

    public Duck(String name, int age, Sex sex) {
        super(name, age, sex);
        super.setRunLimit(50);
        super.setSwimLimit(1000);
        count++;
    }

    public static int getCount() {
        return count;
    }
}
