public class Dog extends Animal {

    private static int count = 0;

    public Dog() {
        count++;
    }

    public Dog(String name, int age, Sex sex) {
        super(name, age, sex);
        super.setRunLimit(500);
        super.setSwimLimit(10);
        count++;
    }

    public static int getCount() {
        return count;
    }
}
