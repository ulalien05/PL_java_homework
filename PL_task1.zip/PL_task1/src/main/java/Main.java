import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Main {

    public static void main(String[] args) throws InstantiationException, IllegalAccessException {
    Animal[] homeZoo = { new Cat("Хаджит", 6, Sex.MALE),
        new Dog("Фенрир", 6, Sex.MALE),
        new Tiger("Миша", 5, Sex.FEMALE),
        new Duck("Лариса", 1, Sex.FEMALE),
        new Fish("Эдуард", 3, Sex.MALE)};

    Random random = new Random();
    List<Animal> animals = new ArrayList<>();

    for (Animal a : homeZoo) {
        a.run(random.nextInt(1000) + 1);
        a.swim(random.nextInt(1000) + 1);
        int arrayLength = random.nextInt(3) + 1;
        for (int i = 0; i < arrayLength ; i++) {
            animals.add(a.getClass().newInstance());
        }
    }
        System.out.println("Всего котов создано: " + Cat.getCount());
        System.out.println("Всего собак создано: " + Dog.getCount());
        System.out.println("Всего уток создано: " + Duck.getCount());
        System.out.println("Всего рыб создано: " + Fish.getCount());
        System.out.println("Всего тигров создано: " + Tiger.getCount());

    }

}
