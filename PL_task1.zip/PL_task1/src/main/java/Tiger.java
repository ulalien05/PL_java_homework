public class Tiger extends Animal {

    private static int count = 0;

    public Tiger() {
        count++;
    }

    public Tiger(String name, int age, Sex sex) {
        super(name, age, sex);
        super.setRunLimit(300);
        super.setSwimLimit(30);
        count++;
    }

    public static int getCount() {
        return count;
    }
}
