public class Fish extends Animal{

    private static int count = 0;

    public Fish() {
        count++;
    }
    public Fish(String name, int age, Sex sex) {
        super(name, age, sex);
        super.setSwimLimit(Integer.MAX_VALUE);
        count++;
    }

    public static int getCount() {
        return count;
    }

    @Override
    public void run(int distance) {
        System.out.printf("%s не умеет бегать, потому что %s - %s.\n", this.getName(),
                this.getSex() == Sex.MALE ? "он" : "она", "рыба");
    }
}
