public class Cat extends Animal{

    private static int count = 0;

    public Cat(String name, int age, Sex sex) {
        super(name, age, sex);
        super.setRunLimit(200);
        count++;
    }

    public Cat() {
        count++;
    }

    public static int getCount() {
        return count;
    }

    @Override
    public void swim(int distance) {
        System.out.printf("%s не умеет плавать, потому что %s - %s.\n", this.getName(),
                this.getSex() == Sex.MALE ? "он" : "она",
                this.getSex() == Sex.MALE ? "кот" : "кошка");
    }
}
