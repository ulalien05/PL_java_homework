import java.io.*;
import java.util.Scanner;

public class Main {


    public static void main(String[] args) throws IOException {

        Scanner scn = new Scanner(System.in);

        System.out.println("Укажите полный путь к папке для сохранения файлов.");
        String folderPath = scn.nextLine();
        scn.close();

        BufferedReader reader = new BufferedReader(new InputStreamReader(Main.class.getClassLoader().getResourceAsStream("poem.txt")));

        StringBuilder builder = new StringBuilder();
        while (reader.ready()) {
            builder.append(reader.readLine()).append("\n");
        }
        reader.close();

        String[] parts = builder.toString().split("\n\n");

        for (int i = 0; i < parts.length; i++) {
            File file = new File(folderPath + "/part" + (i + 1) + ".txt");
            FileWriter fileWriter = new FileWriter(file);
            fileWriter.write(parts[i]);
            fileWriter.close();
        }

    }
}
