import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.LinkedList;
import java.util.Queue;

public class Main {

    public static void main(String[] args) throws IOException, InterruptedException {

        BufferedReader reader = new BufferedReader(new InputStreamReader(Main.class.getClassLoader().getResourceAsStream("poem.txt")));

        StringBuilder builder = new StringBuilder();
        while (reader.ready()) {
            builder.append(reader.readLine()).append("\n");
        }
        reader.close();

        Queue<String> linesQueue = new LinkedList<>();

        String[] parts = builder.toString().split("\n");

        for (String line : parts) {
            if (!line.isEmpty())
                linesQueue.add(line);
        }
        while (linesQueue.peek() != null) {
            Thread.sleep((long) ((Math.random() * 3) * 1000));
            System.out.println(linesQueue.poll());
        }
    }
}
