import java.io.*;
import java.util.*;

public class Main {

    //список недопустимых символов
    static List<Character> invalidSymbols = Arrays.asList('Б', 'б', 'Г', 'г', 'Д', 'д', 'Ë', 'ё', 'Ж', 'ж', 'З', 'з',
            'И', 'и', 'Й', 'й', 'Л', 'л', 'П', 'п', 'Ф', 'ф', 'Ц', 'ц', 'Ч', 'ч', 'Ш', 'ш', 'Щ', 'щ', 'Ъ', 'ъ', 'Ы',
            'ы', 'Ь', 'ь', 'Э', 'э', 'Ю', 'ю', 'Я', 'я');

    public static void main(String[] args) throws IOException {
        System.out.println("Введите регистрационный номер автомобиля.\nДля выхода из программы введите слово \"exit\".");
        Scanner scanner = new Scanner(System.in);
        String input;
        while (!(input = scanner.nextLine()).equals("exit")) {
            validate(input);
        }
        scanner.close();
    }

    public static void validate(String numberPlate) throws IOException {
        //проверка на соответствие длины строки
        if (numberPlate.length() < 8) {
            System.out.println("Госномер должен содержать не менее 8 символов.");
            return;
        }
        char[] chars = numberPlate.toCharArray();
        List<Character> letters = new ArrayList<>();
        List<String> digits = new ArrayList<>();
        for (char c : chars) {
            if (Character.isLetter(c)) {
                //проверка наличия недопустимых символов
                if (invalidSymbols.contains(c)) {
                    System.out.println("В введенном госномере присутствуют недопустимые символы.");
                    return;
                } else
                    letters.add(c);
            } else if (Character.isDigit(c)) {
                digits.add(String.valueOf(c));
            }
        }
        //проверка количества цифровых символоы
        if (digits.size() > 6 || digits.size() < 5) {
            System.out.println("Количество цифр во введенном госномере не соответствует установленному формату.");
            return;
        }
        //получение кода региона в зависимости от количества символов
        String region = digits.size() == 5 ? digits.get(3) + digits.get(4) : digits.get(3) + digits.get(4) + digits.get(5);
        //чтение файла с информацией о кодах регионов
        Map<String, String> regionCodes = new HashMap<>();
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(Main.class.getClassLoader().getResourceAsStream("region_codes.txt")));
        String line;
        while ((line = bufferedReader.readLine()) != null) {
            String[] splitLine = line.split(" - ");
            regionCodes.put(splitLine[0], splitLine[1]);
        }
        //поиск полученного кода в файле
        if (regionCodes.containsKey(region)) {
            StringBuilder sb = new StringBuilder();
            sb.append(letters.get(0) + digits.get(0) + digits.get(1) + digits.get(2) + letters.get(1)
                    + letters.get(2) + region);
            System.out.println("Нормализованный вид госномера: " + sb);
            System.out.println("Введенный госномер зарегистрирован в регионе " + regionCodes.get(region));
        } else {
            System.out.println("Введенный госномер не существует, т.к. в РФ нет региона с кодом " + region);
        }
    }
}
